package com.cg.airlines.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.airlines.dto.Customer;
import com.cg.airlines.exception.CustomerException;
import com.cg.airlines.service.CustomerServiceImpl;
import com.cg.airlines.service.ICustomerService;

public class MainClass {
	static	ICustomerService service=(ICustomerService) new CustomerServiceImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice=0;
		try(Scanner sc=new Scanner(System.in))	//try with source
		{
			do
			{
				System.out.println(" *********************Welcome To Airline Reservation System*****************");
				System.out.println("1-If Admin.");
				System.out.println("2-If Customer.");
				System.out.println("Enter Choice-");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					
					System.out.println("Enter your UserName:");
					String user_Name = sc.next();
					System.out.println("Enter your Password:");
					String passwrd = sc.next();
					if(service.CheckUser(user_Name, passwrd)==null)
					{
						int choice1=0;
						try(Scanner sc1=new Scanner(System.in))	//try with source
						{
							do
							{
								System.out.println("1-Book a Flight for Passengers");
								System.out.println("2-Delete a Booking");
								System.out.println("3-Search Details by BookingId");
								System.out.println("4-Search All Bookings");
								System.out.println("5-Update Passenger Details");
								System.out.println("Enter Choice-");
								choice1=sc1.nextInt();
								switch(choice1)
								{
								case 1: 
									Customer cust = acceptCustomerDetails();
									if(cust!=null)
										try
									{
											int id=service.registerCustomer(cust);
											System.out.println("Tickets Booked and id="+id);
									}
									catch(CustomerException e)
									{
										System.out.println(e.getMessage());
									}
									break;
								case 2:
									System.out.println("Enter BookingId to Delete existing booking:");
									int id = sc.nextInt();
									try
									{
										Customer cust1 = service.removeCustomer(id);
										System.out.println("Booking deleted successfully "+cust1);
									}
									catch(CustomerException e)
									{
										System.out.println(e.getMessage());
									}
									break;
								case 3 : 
									System.out.println("Enter Bookingid to search Customer Details:");
									int bid = sc.nextInt();
									try
									{
										Customer ref = service.getCustomerById(bid);
										System.out.println("Customer details "+ref);
									}
									catch(CustomerException e)
									{
										System.out.println(e.getMessage());
									}
									break;
								case 4:
									try
									{
										ArrayList<Customer>list=service.getAllCustomer();
										for(Customer obj : list)
										{
											System.out.println(obj);
										}
									}
									catch(CustomerException e)
									{
										System.out.println(e.getMessage());
									}

									break;
								case 5:
									System.out.println("Enter BookingId:");
									 int custId = sc.nextInt();
									 System.out.println("Change No of Passengers:");
					                 int noOfPassengers = sc.nextInt();
					                 System.out.println("Change Classtype:");
					                 String classType = sc.next();
					                
					                 try{
						                    Customer cObj = service.updateBooking(custId,noOfPassengers, classType);
						                    System.out.println("updated = "+cObj);
					                    }
					                 catch(CustomerException e)
					                   {
					                    	System.out.println(e.getMessage());
					                   }
					                break;
								}
								System.out.println("Do you to continue 1-Yes, 0-No");
								choice= sc.nextInt();
							}while(choice!=0);
						}
					}
					break;
				case 2:
					int choice11=0;
					try(Scanner sc1=new Scanner(System.in))	//try with source
					{
						do
						{
							System.out.println("1-Book a Flight");
							System.out.println("2-Cancle the Booking");
							System.out.println("Enter Choice-");
							choice11=sc1.nextInt();
							switch(choice11)
							{
							case 1: 
								Customer cust = acceptCustomerDetails();
								if(cust!=null)
									try
								{
										int id=service.registerCustomer(cust);
										System.out.println("Tickets Booked and id="+id);
								}
								catch(CustomerException e)
								{
									System.out.println(e.getMessage());
								}
								break;
							case 2:
								System.out.println("Enter BookingId to Delete existing booking:");
								int id = sc.nextInt();
								try
								{
									Customer cust1 = service.removeCustomer(id);
									System.out.println("Booking deleted successfully "+cust1);
								}
								catch(CustomerException e)
								{
									System.out.println(e.getMessage());
								}
								break;
							}	
							
						}while(choice!=0);
					}
				}
			}while(choice!=0);
			System.exit(choice);
			System.out.println("Thank You");
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	public static Customer acceptCustomerDetails()
	{
		Customer cust = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter your EmailId:");
			String custEmail = sc.next();
			if(!service.validateEmail(custEmail))	
			{
				continue;
			}
			else
			{
				System.out.println("Enter No of Passengers:");
				int noOfPassengers = sc.nextInt();
				System.out.println("Enter ClassType:");
				String classType = sc.next();
				System.out.println("Enter Source City:");
				String srcCity = sc.next();
				System.out.println("Enter Destination City:");
				String destCity = sc.next();
				cust = new Customer();
				cust.setCustEmail(custEmail);
				cust.setNoOfPassengers(noOfPassengers);
				cust.setClassType(classType);
				cust.setSrcCity(srcCity);
				cust.setDestCity(destCity);
				break;
			}

		}
		return cust;
	}
}

