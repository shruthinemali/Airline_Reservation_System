package com.cg.airlines.dto;

public class User {
	private String userName;
	private String pasword;
	private String role;
	private long mobileNo;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", pasword=" + pasword
				+ ", role=" + role + ", mobileNo=" + mobileNo + "]";
	}
	public User(String userName, String pasword, String role, long mobileNo) {
		super();
		this.userName = userName;
		this.pasword = pasword;
		this.role = role;
		this.mobileNo = mobileNo;
	}

	
}
