package com.cg.capstore.service;

import com.cg.capstore.model.FeedbackRating;

public interface ServiceF {
	public void feedback(FeedbackRating feedBackAndRatingDetails);
	public void rating(FeedbackRating feedbackAndRatingDetails);
}
