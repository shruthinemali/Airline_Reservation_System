package com.cg.capstore.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.OrderDao;
import com.cg.capstore.model.AllOrderDetails;



@Transactional
@Service
@Component("orderService")
public class OrderServiceImpl implements OrderService{

	
	@Autowired
	OrderDao orderDao;
	
	@Override
	public ArrayList<AllOrderDetails> getOrders(String emailId) {
		System.out.println("service");
		return orderDao.getOrders(emailId);
	}

}
