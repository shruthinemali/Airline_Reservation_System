package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.Dao;
import com.cg.capstore.model.FeedbackRating;

@Transactional
@Service
@Component("service")
public class ServiceImpl implements ServiceF {

	@Autowired
	Dao dao;
	
	@Override
	public void feedback(FeedbackRating feedbackAndRatingDetails) {
		dao.feedback(feedbackAndRatingDetails);
		
	}

	@Override
	public void rating(FeedbackRating feedbackAndRatingDetails) {
		dao.rating(feedbackAndRatingDetails);
		
	}

}
