package com.cg.capstore.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.model.AllOrderDetails;
import com.cg.capstore.model.Customer;
import com.cg.capstore.model.FeedbackRating;
import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.OrderService;
import com.cg.capstore.service.ServiceF;

@RestController
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
public class ProController {
	int customerId;

	@Autowired
	CustomerService customerService;
	@Autowired
	ServiceF service;
	@Autowired
	OrderService orderService;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String start() {
		
		return "Hello";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public Customer login(@RequestBody Customer c) {
		
		return customerService.login(c);
		
	}
	
	@RequestMapping(value="/orders",method=RequestMethod.POST)
	public ArrayList<AllOrderDetails> getOrders(@RequestBody String emailId) {
		System.out.println("controller");
		return orderService.getOrders(emailId);
		
	}
	@RequestMapping(value="/feedback",method=RequestMethod.POST)
	public void feedback(@RequestBody FeedbackRating feedbackAndRatingDetails) {
		System.out.println("feedback");
		service.feedback(feedbackAndRatingDetails);
	}
	
	@RequestMapping(value="/rating",method=RequestMethod.POST)
	public void rating(@RequestBody FeedbackRating feedbackAndRatingDetails) {
		System.out.println("rating");
		service.rating(feedbackAndRatingDetails);
	}

}
