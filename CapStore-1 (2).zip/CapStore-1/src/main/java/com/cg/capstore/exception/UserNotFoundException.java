package com.cg.capstore.exception;

public class UserNotFoundException extends Exception {

}
