package com.cg.capstore.dao;

import com.cg.capstore.model.FeedbackRating;

public interface Dao {
	public void feedback(FeedbackRating feedbackAndRatingDetails);
	public void rating(FeedbackRating feedbackAndRatingDetails);
}
