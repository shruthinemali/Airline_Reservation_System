package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.capstore.model.Customer;


@Repository
@Component("customerdao")
public class CustomerDaoImpl implements CustomerDao {

	
	@PersistenceContext
	EntityManager entityManger;
	
	@Override
	public Customer login(Customer customer) {
		// TODO Auto-generated method stub
		Query query = entityManger.createQuery("from Customer where emailId = :emailId");
		query.setParameter("emailId", customer.getEmailId());
		System.out.println(customer.getEmailId());
		Customer c= (Customer) query.getSingleResult();
		System.out.println(c.getName());
		if(c.getPassword().equals(customer.getPassword())) {
			 
			return c;
		}
		else
		return null;
}
}
	
