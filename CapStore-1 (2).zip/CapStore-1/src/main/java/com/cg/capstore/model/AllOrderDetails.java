package com.cg.capstore.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class AllOrderDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "order_Sequence")
    @SequenceGenerator(name = "order_Sequence",allocationSize=9001, sequenceName = "ORDER_SEQ")
	private int allOrderId;
	private int orderId;
	private String deliveryStatus;
	private String deliveryDate;
	private int cartId;
	private int productId;
	private int  cartProductQuantity;
	private int cartProductPrice;
	private int customerId;
	private String productName;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getAllOrderId() {
		return allOrderId;
	}
	public void setAllOrderId(int allOrderId) {
		this.allOrderId = allOrderId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getCartProductQuantity() {
		return cartProductQuantity;
	}
	public void setCartProductQuantity(int cartProductQuantity) {
		this.cartProductQuantity = cartProductQuantity;
	}
	public int getCartProductPrice() {
		return cartProductPrice;
	}
	public void setCartProductPrice(int cartProductPrice) {
		this.cartProductPrice = cartProductPrice;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
}
