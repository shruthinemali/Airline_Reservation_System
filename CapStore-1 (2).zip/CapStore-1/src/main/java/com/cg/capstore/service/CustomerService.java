package com.cg.capstore.service;

import com.cg.capstore.model.Customer;



public interface CustomerService {

	public Customer login(Customer c);
}
