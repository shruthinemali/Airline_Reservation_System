package com.cg.capstore.dao;

import java.util.ArrayList;

import com.cg.capstore.model.AllOrderDetails;

public interface OrderDao {

	public ArrayList<AllOrderDetails> getOrders(String emailId);
		
	

}
