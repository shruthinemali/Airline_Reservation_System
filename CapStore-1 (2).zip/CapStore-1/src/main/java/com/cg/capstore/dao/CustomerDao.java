package com.cg.capstore.dao;

import com.cg.capstore.model.Customer;
public interface CustomerDao {

	public Customer login(Customer c);

}
