package com.cg.capstore.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.capstore.model.FeedbackRating;

@Repository
@Component("dao")
public class DaoImpl implements Dao {
	
	FeedbackRating feedbackAndRating;
	ArrayList<Integer> ratings;
	int finalRating;
	int sum=0;

	@PersistenceContext
	EntityManager entityManger;
	
	@Override
	public void feedback(FeedbackRating feedbackAndRatingDetails) {
		
		
		entityManger.persist(feedbackAndRatingDetails);	
	}

	@Override
	public void rating(FeedbackRating feedbackAndRatingDetails) {
		System.out.println(feedbackAndRatingDetails.getCustomerId());
		
		entityManger.persist(feedbackAndRatingDetails);
		
		String hql1 = "select feedAndRating.rating from FeedbackRating feedAndRating where feedAndRating.productId = :productId";
		Query query1 = entityManger.createQuery(hql1);
		query1.setParameter("productId", feedbackAndRatingDetails.getProductId());
		ratings =  (ArrayList<Integer>) query1.getResultList();
	
		for(int i = 0; i < ratings.size(); i++)
		{
		    sum += (int)ratings.get(i);
		}	
		
		finalRating=sum/ratings.size();
		
		Query qry = entityManger.createQuery("update Product product set product.productRating=:rating where product.productId=:productId");
					        qry.setParameter("rating",finalRating);
					        qry.setParameter("productId", feedbackAndRatingDetails.getProductId());
					        qry.executeUpdate();
	}

}
