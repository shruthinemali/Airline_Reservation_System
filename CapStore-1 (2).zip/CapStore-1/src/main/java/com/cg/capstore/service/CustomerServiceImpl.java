package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.CustomerDao;
import com.cg.capstore.model.Customer;

@Transactional
@Service
@Component("customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerdao;
	

	@Override
	public Customer login(Customer c) {
		// TODO Auto-generated method stub
		return customerdao.login(c);
	}

}
