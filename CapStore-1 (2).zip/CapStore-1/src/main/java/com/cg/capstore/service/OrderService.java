package com.cg.capstore.service;

import java.util.ArrayList;

import com.cg.capstore.model.AllOrderDetails;

public interface OrderService {

	
	public ArrayList<AllOrderDetails> getOrders(String emailId);
}
