package com.cg.capstore.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.capstore.model.AllOrderDetails;
import com.cg.capstore.model.Customer;


@Repository
@Component("orderDao")
public class OrderDaoImpl implements OrderDao {

	ArrayList<AllOrderDetails> orders;
	@PersistenceContext
	EntityManager entityManger;
	
	@Override
	public ArrayList<AllOrderDetails> getOrders(String emailId) {
		System.out.println("orders");
		String hql = "from Customer where emailId= :emailId";
		Query query = entityManger.createQuery(hql);
		query.setParameter("emailId", emailId);
		Customer c= (Customer) query.getSingleResult();
		int	customerId=c.getCustomerId();
		System.out.println(c.getCustomerId());
		
		String hql1 = "from AllOrderDetails where customerId= :customerId";
		Query query1 = entityManger.createQuery(hql1);
		query1.setParameter("customerId", customerId);
		orders =  (ArrayList<AllOrderDetails>) query1.getResultList();
		System.out.println("kkk");
		return orders;
	}

}
